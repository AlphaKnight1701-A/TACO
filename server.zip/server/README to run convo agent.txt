Additional system-level requirement:
To play audio with elevenlabs.play, ffmpeg must be installed on your system and available in PATH.

requirements.txt
google-generativeai>=0.8.3
elevenlabs>=1.7.0
sounddevice>=0.4.6
soundfile>=0.12.1
python-dotenv>=1.0.1

Installation commands
# (Optional) Create or activate your conda/venv
conda activate yourenv   # or python -m venv venv && source venv/bin/activate

# Install all dependencies
pip install -r requirements.txt

System setup reminder
Install ffmpeg

or download from https://ffmpeg.org/download.html
 and add it to PATH.

Ensure your .env file contains:
GOOGLE_API_KEY=AIzaSyD6FqtEd4Y6L5xZFVZrAWKFd4tClZJyd38
ELEVENLABS_API_KEY=sk_528432af6b98743d9deb23a9262a2aa692f3b3fbc51bc891
